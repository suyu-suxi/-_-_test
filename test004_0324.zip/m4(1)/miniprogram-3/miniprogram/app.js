App({
  globalData: {
    userInfo: {
      id: 1,
      avatar: '/images/avatar.png',
      nickname: '当前用户',
      supertube: 0
    }
  },
  
  onLaunch() {
    wx.cloud.init({
      env: 'czyyuq668-3gx14c7f26524c39', // 例如 'dev-xxxx'
      traceUser: true,
      success: () => {
          console.log('云开发初始化成功');
      },
      fail: (err) => {
          console.error('云开发初始化失败', err);
      }
  });
  },
});
